from tkinter import*

import patient1
import pupdate
def lk():
    root=Tk()
    root.geometry("1400x1400")
    root.title("QUARANTINE REPORT")

    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "home.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    C.place(x=0,y=0)

    m=Label(root,text="QUARANTINE REPORT",fg="Black",bg="white",width=30,height=2,font=("Arial",25,"bold"))
    m.place(x=400,y=25)
    
    def patientadd():
        patient1.info()
        root.destroy()
    b=Button(root,text="Add Patient Report",command=patientadd,width=23, height=2,fg="Black",bg="white",font=("Times New Roman",15,"bold"))
    b.place(x=580,y=300)

    def patupdate():
        pupdate.ck()
        root.destroy()
    b1=Button(root,text="Update Report",command=patupdate,width=23, height=2,fg="Black",bg="white",font=("Times New Roman",15,"bold"))
    b1.place(x=580,y=400)


    def back():
        import ureport
        ureport.dk()
        root.destroy()
    b2=Button(root,text="Back",command=back,width=23, height=2,fg="Black",bg="white",font=("Times New Roman",15,"bold"))
    b2.place(x=580,y=500)
    root.mainloop()
    

