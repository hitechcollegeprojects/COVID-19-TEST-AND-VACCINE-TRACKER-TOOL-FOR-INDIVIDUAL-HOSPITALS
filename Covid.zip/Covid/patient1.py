from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg
from tkcalendar import Calendar, DateEntry
import pat
def info():
    root=Tk()
    root.geometry("1400x1400")
    root.title("ADD QUARANTINE PAITENTS INFO")
    root.configure(bg='#856ff8')
    m=Label(root,text="PATIENTS INFORMATION",fg="black",bg="white",width=20,font=("Arial",25,"bold"))
    m.place(x=450,y=15)
    
    w=Label(root,text="Patient ID",width=20,height=2)
    w.place(x=400,y=100)
    t=Entry(root,borderwidth=5, width = 50)
    t.place(x=600,y=100)
    
    w1=Label(root,text="Name",width=20,height=2)
    w1.place(x=400,y=150)
    t1=Entry(root,borderwidth=5, width = 50)
    t1.place(x=600,y=150)
    
    w2=Label(root,text="Contact Number",width=20,height=2)
    w2.place(x=400,y=200)   
    t2=Entry(root,borderwidth=5, width = 50)
    t2.place(x=600,y=200)
    
    w3=Label(root,text="Date of Birth",width=20,height=2)
    w3.place(x=400,y=250)
    t3 = DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t3.place(x=600,y=250)
    
    w4=Label(root,text="Gender",width=20,height=2)
    w4.place(x=400,y=300)  
    t4 = StringVar()
    t4.set('Female')
    r1 = Radiobutton(root, text='Male', variable=t4, value='Male')
    r1.place(x=600,y=300)

    r2 = Radiobutton(root, text='Female', variable=t4, value='Female')
    r2.place(x=700,y=300)

    w5=Label(root,text="Date",width=20,height=2)
    w5.place(x=400,y=350)
    t5=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t5.place(x=600,y=350)
    
    w6=Label(root,text="Blood Group",width=20,height=2)
    w6.place(x=400,y=400)
    t6 = StringVar(root)
    t6.set("Select") 

    a= OptionMenu(root, t6, "B+ve", "O+ve", "A+ve", "A-ve", "O-ve", "AB+ve", "AB-ve")
    a.config(width=20, font=('Helvetica', 12))
    a.place(x=600,y=400)

    w7=Label(root,text="Quarantine Start Date",width=20,height=2)
    w7.place(x=400,y=450)
    t7=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t7.place(x=600,y=450)

    w8=Label(root,text="Quarantine End Date",width=20,height=2)
    w8.place(x=400,y=500)
    t8=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t8.place(x=600,y=500)

    w9=Label(root,text="Next Check Up",width=20,height=2)
    w9.place(x=400,y=550)
    t9=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t9.place(x=600,y=550)

    w10=Label(root,text="Quarantine Status",width=20,height=2)
    w10.place(x=400,y=600)
    t10= StringVar()
    t10.set('Home Quarantine')
    r1 = Radiobutton(root, text='Home Quarantine', variable=t10, value='Home Quarantine')
    r1.place(x=600,y=600)

    r2 = Radiobutton(root, text='Admitted In Hospital', variable=t10, value='Admitted In Hospital')
    r2.place(x=750,y=600)

    
    w11=Label(root,text="Address",width=20,height=2)
    w11.place(x=400,y=650)
    t11=Text(root,borderwidth=4, width = 40,height=4)
    t11.place(x=600,y=650)


    
    def att():
        con=my.connect(host="localhost",user="root",password="123456",database="covid")
        cursor=con.cursor()
        c="INSERT INTO pat(id,name,mobile,dob,gender,date,bg,start_date,end_date,checkup,qstatus,address) values('"+t.get()+"','"+t1.get()+"','"+t2.get()+"','"+t3.get()+"','"+t4.get()+"','"+t5.get()+"','"+t6.get()+"','"+t7.get()+"','"+t8.get()+"','"+t9.get()+"','"+t10.get()+"','"+t11.get("1.0",END)+"')"
        cursor.execute(c)
        cursor.execute("commit")
        msg.showinfo("Submit Status","Added Successfully")
        t.delete(0, END)
        t1.delete(0, END)
        t2.delete(0, END)
        t3.delete(0, END)
        t5.delete(0, END)
        t7.delete(0, END)
        t8.delete(0, END)
        t9.delete(0, END)
        t11.delete(1.0, END)

    b=Button(root,text="Submit",command=att,width=20, height=2)
    b.place(x=1000,y=300)
    
    def Clear():
        t.delete(0, END)
        t1.delete(0, END)
        t2.delete(0, END)
        t3.delete(0, END)
        t5.delete(0, END)
        t7.delete(0, END)
        t8.delete(0, END)
        t9.delete(0, END)
        t11.delete(1.0, END)

    
    b1= Button(root, text="Clear",width=20, height=2,command=Clear)
    b1.place(x=1000,y=350)

    def back():
        pat.lk()
        root.destroy()
    b2=Button(root,text="Back",command=back,width=20, height=2)
    b2.place(x=1000,y=400)




    
    
