from tkinter import*
import mysql.connector as my

def ty():
    root=Tk()
    root.geometry("1200x600")
    root.title("hlogin")
    root.configure(bg='#856ff8')
    w=Label(root,text="Hospital Name")
    w.place(x=200,y=200)
    w1=Label(root,text="Hospital Location")
    w1.place(x=200,y=250)
    w2=Label(root,text="Hospital Address")
    w2.place(x=200,y=300)
    w3=Label(root,text="Date")
    w3.place(x=200,y=350)
    t=Entry(root,borderwidth=3, width = 50)
    t.place(x=300,y=200)
    t1=Entry(root,borderwidth=3, width = 50)
    t1.place(x=300,y=250)
    t2=Entry(root,borderwidth=3, width = 50)
    t2.place(x=300,y=300)
    t3=Entry(root,borderwidth=3, width = 50)
    t3.place(x=300,y=350)



    b=Button(root,text="Submit")
    b.place(x=300,y=400)
