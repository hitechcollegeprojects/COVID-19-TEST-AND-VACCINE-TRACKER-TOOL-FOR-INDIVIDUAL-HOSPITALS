from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg
from tkcalendar import Calendar, DateEntry



def vacc():
    root=Tk()
    root.geometry("1400x1400")
    root.title("VACCINE INFORMATION")
    root.configure(bg='#856ff8')

    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "1.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    C.place(x=0,y=0)
    
    m=Label(root,text="VACCINE INFORMATION",fg="black",bg="white",width=30,height=2,font=("Arial",16,"bold"))
    m.place(x=500,y=15)
    
    w=Label(root,text="Patient ID",width=20,height=2,font=("Times New Roman",12,"bold"))
    w.place(x=350,y=130)
    t=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12,"bold"))
    t.place(x=600,y=130)
    
    w1=Label(root,text="Name",width=20,height=2,font=("Times New Roman",12,"bold"))
    w1.place(x=350,y=180)
    t1=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12,"bold"))
    t1.place(x=600,y=180)
    
    w2=Label(root,text="Contact Number",width=20,height=2,font=("Times New Roman",12,"bold"))
    w2.place(x=350,y=230)
    t2=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12,"bold"))
    t2.place(x=600,y=230)
    
    w3=Label(root,text="Date of Birth",width=20,height=2,font=("Times New Roman",12,"bold"))
    w3.place(x=350,y=280)
    t3 = DateEntry(root, width= 40, background= "magenta3", foreground= "white",bd=2,font=("Times New Roman",12,"bold"))
    t3.place(x=600,y=280)
    
    w4=Label(root,text="Gender",width=20,height=2,font=("Times New Roman",12,"bold"))
    w4.place(x=350,y=330)  
    t4 = StringVar()
    t4.set('Female')
    r1 = Radiobutton(root, text='Male', variable=t4, value='Male',font=("Times New Roman",12,"bold"))
    r1.place(x=600,y=330)

    r2 = Radiobutton(root, text='Female', variable=t4, value='Female',font=("Times New Roman",12,"bold"))
    r2.place(x=700,y=330)
    
    w5=Label(root,text="Age",width=20,height=2,font=("Times New Roman",12,"bold"))
    w5.place(x=350,y=380)
    t5=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12,"bold"))
    t5.place(x=600,y=380)
    
    
    w6=Label(root,text="Date",width=20,height=2,font=("Times New Roman",12,"bold"))
    w6.place(x=350,y=430)
    t6=DateEntry(root, width= 40, background= "magenta3", foreground= "white",bd=2,font=("Times New Roman",12,"bold"))
    t6.place(x=600,y=430)

    w7=Label(root,text="select vaccine",width=20,height=2,font=("Times New Roman",12,"bold"))
    w7.place(x=350,y=480)
    t7 = StringVar(root)
    t7.set("Select") 

    a= OptionMenu(root, t7, "Sinopharm", "Sinovac", "Pfizer-BioNTech", "Moderna", "Oxford-AstraZeneca", "Sputnik V", "Novavax")
    a.config(width=20,font=("Times New Roman",12,"bold"))
    a.place(x=600,y=480)
    
    w8=Label(root,text="Second Dose Date",width=20,height=2,font=("Times New Roman",12,"bold"))
    w8.place(x=350,y=530)
    t8=DateEntry(root, width= 40, background= "magenta3", foreground= "white",bd=2,font=("Times New Roman",12,"bold"))
    t8.place(x=600,y=530)

    
    w9=Label(root,text="Address",width=20,height=2,font=("Times New Roman",12,"bold"))
    w9.place(x=350,y=600)
    t9=Text(root,borderwidth=4, width = 40,height=4,font=("Times New Roman",12,"bold"))
    t9.place(x=600,y=580)



    def att():
        con=my.connect(host="localhost",user="root",password="123456",database="covid")
        cursor=con.cursor()
        c="INSERT INTO vaccine(id,name,contact,dob,gender,age,date,vaccine,seconddose,address) values('"+t.get()+"','"+t1.get()+"','"+t2.get()+"','"+t3.get()+"','"+t4.get()+"','"+t5.get()+"','"+t6.get()+"','"+t7.get()+"','"+t8.get()+"','"+t9.get("1.0",END)+"')"
        cursor.execute(c)
        cursor.execute("commit")
        msg.showinfo("Submit Status","Added Successfully")
        t.delete(0, END)
        t1.delete(0, END)
        t2.delete(0, END)
        t3.delete(0, END)
        t5.delete(0, END)
        t6.delete(0, END)
        t8.delete(0, END)
        t9.delete(1.0, END)
    b=Button(root,text="Submit",command=att,width=20, height=2,font=("Times New Roman",12,"bold"))
    b.place(x=1000,y=200)
    
    def Clear():
        t.delete(0, END)
        t1.delete(0, END)
        t2.delete(0, END)
        t3.delete(0, END)
        t5.delete(0, END)
        t6.delete(0, END)
        t8.delete(0, END)
        t9.delete(1.0, END) 
    
    
    b1= Button(root, text="Clear",width=20, height=2,command=Clear,font=("Times New Roman",12,"bold"))
    b1.place(x=1000,y=300)

    def back():
        import vaccine
        vaccine.bk()
        top.quit()
    b2=Button(root,text="Back",command=back,width=20, height=2,font=("Times New Roman",12,"bold"))
    b2.place(x=1000,y=400)
    root.mainloop()
    




    
    
