from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg

def ct():
    root=Tk()
    root.geometry("1400x1400")
    root.title("COVID TEST")
    
    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "home.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    C.place(x=0,y=0)
    
    m=Label(root,text="COVID-19 TEST",fg="black",bg="white",width=30,height=2,font=("Arial",25,"bold"))
    m.place(x=400,y=15)
    
    w=Label(root,text="User Name",width=20,height=2)
    w.place(x=450,y=250)
    t=Entry(root,borderwidth=2, width = 25)
    t.place(x=650,y=250)
    
    w1=Label(root,text="Password",width=20,height=2)
    w1.place(x=450,y=300)
    t1=Entry(root,borderwidth=2, width = 25)
    t1.place(x=650,y=300)
    
    
    def att():
        con=my.connect(host="localhost",user="root",password="123456",database="covid")
        cursor=con.cursor()
        c="INSERT INTO userlogin(username,password) values('"+t.get()+"','"+t1.get()+"')"
        cursor.execute(c)
        cursor.execute("commit")
        msg.showinfo("Submit Status","Added Successfully")
        t.delete(0, END)
        t1.delete(0, END)

    b=Button(root,text="Submit",command=att,width=15, height=2)
    b.place(x=480,y=380)
    


    def back():
        import admin_report
        admin_report.dk()
        root.destroy()
    b2=Button(root,text="Back",command=back,width=15, height=2)
    b2.place(x=650,y=380)
    root.mainloop()



    
    
