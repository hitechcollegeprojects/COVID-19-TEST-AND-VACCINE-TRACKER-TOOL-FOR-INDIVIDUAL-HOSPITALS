from tkinter import*
import admin_report
from tkcalendar import Calendar, DateEntry
from tkinter import ttk
from tkinter import messagebox as msg
from tkinter import filedialog
import csv
import os
import mysql.connector as my
mydata=[]
def dr():
     
    db=my.connect(host="localhost",user="root",password="123456",database="covid")
    cur=db.cursor()
    root=Toplevel()
    root.geometry("1600x1600")
    root.title("VACCINE REPORT")
    bg = PhotoImage(file = "2.png")
    # Create Canvas
    canvas1 = Canvas( root, width = 400,height = 400)
    canvas1.pack(fill = "both", expand = True)
    # Display image
    canvas1.create_image( 0, 0, image = bg,anchor = "nw")
    m=Label(root,text="LOCAL REPORT",fg="black",bg="pink",borderwidth=5, width = 50)
    m.place(x=600,y=50)
  
        
    w=Label(root,text="Starting Date")
    w.place(x=500,y=200)
    
    z=Label(root,text="Ending Date")
    z.place(x=500,y=250)

    
    t=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t.place(x=700,y=200)
 
    t1=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t1.place(x=700,y=250)
   
    xyz=LabelFrame(root,text="Report")
    xyz.pack(fill="both",expand="yes",padx=20,pady=10)
    trv=ttk.Treeview(xyz,columns=(1,2,3,4,5,6,7,8,9,10),show="headings",height="7")
    trv.pack()
    

    trv.heading(1,text="Id")
    trv.heading(2,text="Name")
    trv.heading(3,text="Contact")
    trv.heading(4,text="DOB")
    trv.heading(5,text="Gender")
    trv.heading(6,text="Age")
    trv.heading(7,text="Date")
    trv.heading(8,text="Vaccine")
    trv.heading(9,text="SecondDose")
    trv.heading(10,text="Address")


    trv.column(1,width=100)
    trv.column(2,width=100)
    trv.column(3,width=150)
    trv.column(4,width=200)
    trv.column(5,width=100)
    trv.column(6,width=100)
    trv.column(7,width=100)
    trv.column(8,width=100)
    trv.column(9,width=100)
    trv.column(10,width=100)


    
    sc=Scrollbar(xyz,orient=VERTICAL,command=trv.yview)
    sc1=Scrollbar(xyz,orient=HORIZONTAL,command=trv.xview)
    trv.configure(xscrollcommand=sc1.set,yscrollcommand=sc.set)
    
    sc.pack(side=RIGHT,fill=Y)
    sc1.pack(side=BOTTOM,fill=X)
    def data():
        sql="select * from vaccine where date between '"+t.get()+"' and '"+t1.get()+"'"
        cur.execute(sql)
        rows=cur.fetchall()
        global mydata
        mydata=rows
        trv.delete(*trv.get_children()) 
        for i in rows:
            trv.insert('','end',values=i)
    b1=Button(root,text="view",command=data)
    b1.place(x=700,y=400)

    def export():
        if len(trv.get_children()) < 1:
            msg.showerror("No Data","No data Available to export")
            return False
        fln=filedialog.asksaveasfilename(initialdir=os.getcwd(),title="Save CSV",filetypes=(("CSV File",".csv"),("All Files",".*")))
        with open(fln,mode='w' ) as myfile:
            exp=csv.writer(myfile,delimiter=",")
            for i in mydata:
                exp.writerow(i)
        msg.showinfo("Export Status","Exported Successfuly")
        

    b2=Button(root,text="Export",command=export)
    b2.place(x=700,y=700)
    
    def back():
        admin_report.dk()
        root.destroy()
    b=Button(root,text="Back",command=back)
    b.place(x=800,y=700)
    root.mainloop()

