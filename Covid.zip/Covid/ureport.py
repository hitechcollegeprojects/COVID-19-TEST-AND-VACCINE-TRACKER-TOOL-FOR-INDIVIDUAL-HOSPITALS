from tkinter import*
def dk():
    root=Tk()
    root.geometry("1400x1400")
    root.title("User Report")
  
    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "6.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    C.place(x=0,y=0)


    def vaccineupdate():
        import vaccine
        root.destroy()
        vaccine.bk()
        
    b=Button(root,text="Vaccine Update",command=vaccineupdate,width=23, height=2,fg="Black",bg="white",font=("Trebuchet MS",12,"bold"))
    b.place(x=390,y=300)

    def testreport():
        import test
        test.cl()
        root.destroy()
    b1=Button(root,text="Covid-19 Test",command=testreport,width=23, height=2,fg="Black",bg="white",font=("Trebuchet MS",12,"bold"))
    b1.place(x=630,y=300)

    def patientinfo():
        import pat
        pat.lk()
        root.destroy()
    b2=Button(root,text="Quarantine Info",command=patientinfo,width=23, height=2,fg="Black",bg="white",font=("Trebuchet MS",12,"bold"))
    b2.place(x=870,y=300)
    
    def close():
        root.destroy()
    b2=Button(root,text="Exit",command=close,width=23, height=2,fg="Black",bg="white",font=("Trebuchet MS",12,"bold"))
    b2.place(x=630,y=400)
    root.mainloop()


