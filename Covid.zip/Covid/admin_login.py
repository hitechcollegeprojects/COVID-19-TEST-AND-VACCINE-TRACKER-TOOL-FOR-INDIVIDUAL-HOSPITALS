from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg
import admin_report
def alogin():
    root=Toplevel()
    root.geometry("1400x1400")
    root.title("Admin Login")
    root.configure()
    
    bg = PhotoImage(file = "2.png")
    # Create Canvas
    canvas1 = Canvas( root, width = 400,height = 400)
    canvas1.pack(fill = "both", expand = True)
    # Display image
    canvas1.create_image( 0, 0, image = bg,anchor = "nw")
    
    m=Label(root,text="ADMIN LOGIN",fg="Black",width=30,height=2,font=("Arial",25,"bold"))
    m.place(x=400,y=30)
    
    w=Label(root,text="User Name",width=15, height=2,fg="Black",bg="white",font=("Times",13,"bold"))
    w.place(x=500,y=300)
    z=Label(root,text="Password",width=15, height=2,fg="Black",bg="white",font=("Times",13,"bold"))
    z.place(x=500,y=400)
    t=Entry(root,borderwidth=2, width = 25,font=("Arial",13,"bold"))
    t.place(x=680,y=315)
    t1=Entry(root,borderwidth=2, width = 25, show="*",font=("Arial",13,"bold"))
    t1.place(x=680,y=415)
    
    def llen():
        con=my.connect(host="localhost",user="root",password="123456",database="covid")
        cur=con.cursor()
        cur.execute("select * from adminlogin where username='"+t.get()+"' and password='"+t1.get()+"'")
        d=cur.fetchall()
        if d:
            msg.showinfo("Login Status","Login Successfully "+t.get())
            for x in d:
                admin_report.dk()
                root.destroy()
        else:
            msg.showinfo("Login Status","Username/Password Invalid "+t.get())
    b=Button(root,text="Login",command=llen,width=10,height=1,fg="Black",bg="white",font=("Times",12,"bold"))
    b.place(x=640,y=500)
    root.mainloop()





    
