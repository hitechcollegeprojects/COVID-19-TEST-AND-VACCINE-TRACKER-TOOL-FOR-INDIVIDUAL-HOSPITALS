from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg
from tkcalendar import Calendar, DateEntry
import pat
def ck():
    root=Tk()
    root.geometry("1400x1400")
    root.title("UPDATE PAITENTS INFO")
    root.configure(bg='#856ff8')
    m=Label(root,text="UPDATE PATIENTS INFO",fg="black",bg="white",width=30,height=2)
    m.place(x=500,y=15)
    
    w=Label(root,text="Patient ID",width=20,height=2)
    w.place(x=400,y=100)
    t=Entry(root,borderwidth=5, width = 50)
    t.place(x=600,y=100)
    
    w1=Label(root,text="Name",width=20,height=2)
    w1.place(x=400,y=150)
    t1=Entry(root,borderwidth=5, width = 50)
    t1.place(x=600,y=150)
    
    w2=Label(root,text="Contact Number",width=20,height=2)
    w2.place(x=400,y=200)   
    t2=Entry(root,borderwidth=5, width = 50)
    t2.place(x=600,y=200)
    
    w3=Label(root,text="Date of Birth",width=20,height=2)
    w3.place(x=400,y=250)
    t3 = Entry(root,borderwidth=5, width = 50)
    t3.place(x=600,y=250)
    
    w4=Label(root,text="Gender",width=20,height=2)
    w4.place(x=400,y=300)  
    t4 =Entry(root,borderwidth=5, width = 50)
    t4.place(x=600,y=300)


    w5=Label(root,text="Date",width=20,height=2)
    w5.place(x=400,y=350)
    t5=Entry(root,borderwidth=5, width = 50)
    t5.place(x=600,y=350)
    
    w6=Label(root,text="Blood Group",width=20,height=2)
    w6.place(x=400,y=400)
    t6 = Entry(root,borderwidth=5, width = 50)
    t6.place(x=600,y=400)

    w7=Label(root,text="Quarantine Start Date",width=20,height=2)
    w7.place(x=400,y=450)
    t7=Entry(root,borderwidth=5, width = 50)
    t7.place(x=600,y=450)

    w8=Label(root,text="Quarantine End Date",width=20,height=2)
    w8.place(x=400,y=500)
    t8=Entry(root,borderwidth=5, width = 50)
    t8.place(x=600,y=500)

    w9=Label(root,text="Next Check Up",width=20,height=2)
    w9.place(x=400,y=550)
    t9=Entry(root,borderwidth=5, width = 50)
    t9.place(x=600,y=550)

    w10=Label(root,text="Quarantine Status",width=20,height=2)
    w10.place(x=400,y=600)
    t10= Entry(root,borderwidth=5, width = 50)
    t10.place(x=600,y=600)

    
    w11=Label(root,text="Address",width=20,height=2)
    w11.place(x=400,y=650)
    t11=Entry(root,borderwidth=5, width = 50)
    t11.place(x=600,y=650)

    def retrive():
        i=0
        id=t.get()
        if (id==""):
            msg.showinfo("Retrive Status","Required Id Field")
        else:
            con=my.connect(host="localhost",user="root",password="123456",database="covid")
            cursor=con.cursor()
            cursor.execute("select * from pat where id='"+id+"'")
            rows=cursor.fetchall()

            for i in rows:
                t1.insert(0,i[1])
                t2.insert(0,i[2])
                t3.insert(0,i[3])
                t4.insert(0,i[4])
                t5.insert(0,i[5])
                t6.insert(0,i[6])
                t7.insert(0,i[7])
                t8.insert(0,i[8])
                t9.insert(0,i[9])
                t10.insert(0,i[10])
                t11.insert(0,i[11])
                
                msg.showinfo("Retrive Status","Record Found")
            if i not in rows:
                msg.showinfo("Retrive Status","Record Not Found")
            con.close();

    b=Button(root,text="Search",command=retrive,width=20, height=2)
    b.place(x=1000,y=200)


    def update():
        id=t.get()
    
        if (id==" "):
            msg.showinfo("Update Status","All the Fields")
        else:
            con=my.connect(host="localhost",user="root",password="123456",database="covid")
            cursor=con.cursor()
            cursor.execute("update pat set name='"+t1.get()+"',mobile='"+t2.get()+"',dob='"+t3.get()+"',gender='"+t4.get()+"',date='"+t5.get()+"',bg='"+t6.get()+"',start_date='"+t7.get()+"',end_date='"+t8.get()+"',checkup='"+t9.get()+"',qstatus='"+t10.get()+"',address='"+t11.get()+"'  where id='"+t.get()+"'")
            cursor.execute("commit");
            msg.showinfo("Update Status","Updated Successfully")
            con.close();
            t.delete(0,END)
            t1.delete(0,END)
            t2.delete(0,END)
            t3.delete(0,END)
            t4.delete(0,END)
            t5.delete(0,END)
            t6.delete(0,END)
            t7.delete(0,END)
            t8.delete(0,END)
            t9.delete(0,END)
            t10.delete(0,END)
            t11.delete(0,END)
    b1=Button(root,text="Update",command=update,width=20, height=2)
    b1.place(x=1000,y=250)

    def delete():
        id=t.get()
    
        if (id==""):
            msg.showinfo("Delete Status","All the Fields")
        else:
            con=my.connect(host="localhost",user="root",password="123456",database="covid")
            cursor=con.cursor()
            cursor.execute("delete from pat where id='"+id+"'")
            cursor.execute("commit");
            msg.showinfo("Delete Status","Deleted Successfully")
            con.close();
            t.delete(0,END)
            t1.delete(0,END)
            t2.delete(0,END)
            t3.delete(0,END)
            t4.delete(0,END)
            t5.delete(0,END)
            t6.delete(0,END)
            t7.delete(0,END)
            t8.delete(0,END)
            t9.delete(0,END)
            t10.delete(0,END)
            t11.delete(0,END)
    b2=Button(root,text="Delete",command=delete,width=20, height=2)
    b2.place(x=1000,y=300)
    
    def clear():
        msg.showinfo("Reset Status","Reset Successfull")
        t.delete(0,END)
        t1.delete(0,END)
        t2.delete(0,END)
        t3.delete(0,END)
        t4.delete(0,END)
        t5.delete(0,END)
        t6.delete(0,END)
        t7.delete(0,END)
        t8.delete(0,END)
        t9.delete(0,END)
        t10.delete(0,END)
        t11.delete(0,END)
    b3=Button(root,text="Reset",command=clear,width=20, height=2)
    b3.place(x=1000,y=350)

    def back():
        pat.lk()
        root.destroy()
    b4=Button(root,text="Back",command=back,width=20, height=2)
    b4.place(x=1000,y=400)

    def exit():
        root.destroy()
    b5=Button(root,text="Exit",command=exit,width=20, height=2)
    b5.place(x=1000,y=450)



    
    
