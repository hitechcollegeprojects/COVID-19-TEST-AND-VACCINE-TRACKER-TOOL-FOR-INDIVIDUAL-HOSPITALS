from tkinter import*
import usermanage
import vaccinerep
import covidrep
import patrep
def dk():
    root=Toplevel()
    root.geometry("1400x1400")
    root.title("ADMIN REPORT")
    root.configure()
    bg = PhotoImage(file = "6.png")
    # Create Canvas
    canvas1 = Canvas( root, width = 400,height = 400)
    canvas1.pack(fill = "both", expand = True)
    # Display image
    canvas1.create_image( 0, 0, image = bg,anchor = "nw")
    m=Label(root,text="ADMIN REPORTS",fg="Black",bg="white",width=30,height=2,font=("Arial",25,"bold"))
    m.place(x=400,y=25)

    def userreport():
        usermanage.ct()
    b=Button(root,text="User Management",command=userreport,width=23, height=2,fg="Black",bg="white",font=("Palatino",12,"bold"))
    b.place(x=550,y=200)

    def vaccinereport():
        vaccinerep.dr()
    b1=Button(root,text="Vaccine Report",command=vaccinereport,width=23, height=2,fg="Black",bg="white",font=("Palatino",12,"bold"))
    b1.place(x=550,y=300)

    def covidresultreport():
        covidrep.cr()
    b2=Button(root,text="Covid-19 Report",command=covidresultreport,width=23, height=2,fg="Black",bg="white",font=("Palatino",12,"bold"))
    b2.place(x=550,y=400)

    def quarantinereport():
        patrep.dr()
    b2=Button(root,text="Quarantine Report",command=quarantinereport,width=23, height=2,fg="Black",bg="white",font=("Palatino",12,"bold"))
    b2.place(x=550,y=500)
    
    def back():
        pass
        root.destroy()
    b2=Button(root,text="Back",command=back,width=23, height=2,fg="Black",bg="white",font=("Palatino",12,"bold"))
    b2.place(x=550,y=600)
    root.mainloop()
    



