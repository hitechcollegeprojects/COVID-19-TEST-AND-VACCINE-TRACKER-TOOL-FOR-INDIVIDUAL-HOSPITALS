from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg
from tkcalendar import Calendar, DateEntry

def ek():
    root=Tk()
    root.geometry("1400x1400")
    root.title("VACCINE UPDATE")
    
    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "1.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    C.place(x=0,y=0)
    
    m=Label(root,text="VACCINE",fg="black",bg="white",width=30,height=2,font=("Arial",16,"bold"))
    m.place(x=500,y=15)
    
    w=Label(root,text="Patient ID",width=20,height=2,font=("Times New Roman",12,"bold"))
    w.place(x=400,y=150)
    t=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t.place(x=600,y=150)
    
    w1=Label(root,text="Name",width=20,height=2,font=("Times New Roman",12,"bold"))
    w1.place(x=400,y=200)
    t1=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t1.place(x=600,y=200)
    
    w2=Label(root,text="Contact Number",width=20,height=2,font=("Times New Roman",12,"bold"))
    w2.place(x=400,y=250)
    t2=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t2.place(x=600,y=250)
    
    w3=Label(root,text="Date of Birth",width=20,height=2,font=("Times New Roman",12,"bold"))
    w3.place(x=400,y=300)
    t3 = Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t3.place(x=600,y=300)
    
    w4=Label(root,text="Gender",width=20,height=2,font=("Times New Roman",12,"bold"))
    w4.place(x=400,y=350)  
    t4 = Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t4.place(x=600,y=350)
    
    w5=Label(root,text="Age",width=20,height=2,font=("Times New Roman",12,"bold"))
    w5.place(x=400,y=400)
    t5=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t5.place(x=600,y=400)
    
    
    w6=Label(root,text="Date",width=20,height=2,font=("Times New Roman",12,"bold"))
    w6.place(x=400,y=450)
    t6=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t6.place(x=600,y=450)

    w7=Label(root,text="select vaccine",width=20,height=2,font=("Times New Roman",12,"bold"))
    w7.place(x=400,y=500)
    t7 = Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t7.place(x=600,y=500)
    
    w8=Label(root,text="Second Dose Date",width=20,height=2,font=("Times New Roman",12,"bold"))
    w8.place(x=400,y=550)
    t8=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t8.place(x=600,y=550)

    
    w9=Label(root,text="Address",width=20,height=2,font=("Times New Roman",12,"bold"))
    w9.place(x=400,y=600)
    t9=Entry(root,borderwidth=5, width = 40,font=("Times New Roman",12))
    t9.place(x=600,y=600)

    def retrive():
        i=0
        id=t.get()
        if (id==""):
            msg.showinfo("Retrive Status","Required Id Field")
        else:
            con=my.connect(host="localhost",user="root",password="123456",database="covid")
            cursor=con.cursor()
            cursor.execute("select * from vaccine where id='"+id+"'")
            rows=cursor.fetchall()

            for i in rows:
                t1.insert(0,i[1])
                t2.insert(0,i[2])
                t3.insert(0,i[3])
                t4.insert(0,i[4])
                t5.insert(0,i[5])
                t6.insert(0,i[6])
                t7.insert(0,i[7])
                t8.insert(0,i[8])
                t9.insert(0,i[9])
                
                msg.showinfo("Retrive Status","Record Found")
            if i not in rows:
                msg.showinfo("Retrive Status","Record Not Found")
            con.close();

    b=Button(root,text="Search",command=retrive,width=10, height=2,font=("Times New Roman",12,"bold"))
    b.place(x=1000,y=180)


    def update():
        id=t.get()
    
        if (id==" "):
            msg.showinfo("Update Status","All the Fields")
        else:
            con=my.connect(host="localhost",user="root",password="123456",database="covid")
            cursor=con.cursor()
            cursor.execute("update vaccine set name='"+t1.get()+"',contact='"+t2.get()+"',dob='"+t3.get()+"',gender='"+t4.get()+"',age='"+t5.get()+"',date='"+t6.get()+"',vaccine='"+t7.get()+"',seconddose='"+t8.get()+"',address='"+t9.get()+"' where id='"+t.get()+"'")
            cursor.execute("commit");
            msg.showinfo("Update Status","Updated Successfully")
            con.close();
            t.delete(0,END)
            t1.delete(0,END)
            t2.delete(0,END)
            t3.delete(0,END)
            t4.delete(0,END)
            t5.delete(0,END)
            t6.delete(0,END)
            t7.delete(0,END)
            t8.delete(0,END)
            t9.delete(0,END)
    b1=Button(root,text="Update",command=update,width=10, height=2,font=("Times New Roman",12,"bold"))
    b1.place(x=1000,y=250)

    def delete():
        id=t.get()
    
        if (id==""):
            msg.showinfo("Delete Status","All the Fields")
        else:
            con=my.connect(host="localhost",user="root",password="123456",database="covid")
            cursor=con.cursor()
            cursor.execute("delete from vaccine where id='"+id+"'")
            cursor.execute("commit");
            msg.showinfo("Delete Status","Deleted Successfully")
            con.close();
            t.delete(0,END)
            t1.delete(0,END)
            t2.delete(0,END)
            t3.delete(0,END)
            t4.delete(0,END)
            t5.delete(0,END)
            t6.delete(0,END)
            t7.delete(0,END)
            t8.delete(0,END)
            t9.delete(0,END)
    b2=Button(root,text="Delete",command=delete,width=10, height=2,font=("Times New Roman",12,"bold"))
    b2.place(x=1000,y=320)
    
    def clear():
        msg.showinfo("Reset Status","Reset Successfull")
        t.delete(0,END)
        t1.delete(0,END)
        t2.delete(0,END)
        t3.delete(0,END)
        t4.delete(0,END)
        t5.delete(0,END)
        t6.delete(0,END)
        t7.delete(0,END)
        t8.delete(0,END)
        t9.delete(0,END)
    b3=Button(root,text="Reset",command=clear,width=10, height=2,font=("Times New Roman",12,"bold"))
    b3.place(x=1000,y=390)

    def back():
        import vaccine
        vaccine.bk()
        root.destroy()
    b4=Button(root,text="Back",command=back,width=10, height=2,font=("Times New Roman",12,"bold"))
    b4.place(x=1000,y=460)

    def close():
        root.destroy()
    b5=Button(root,text="Exit",command=close,width=10, height=2,font=("Times New Roman",12,"bold"))
    b5.place(x=1000,y=530)
    root.mainloop()
    
