from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg
from tkcalendar import Calendar, DateEntry
import test
def ct():
    root=Tk()
    root.geometry("1400x1400")
    root.title("COVID TEST")
    root.configure(bg='#856ff8')
    m=Label(root,text="COVID-19 TEST",fg="black",bg="white",width=30,height=2,font=("Arial",16,"bold"))
    m.place(x=400,y=15)
    
    w=Label(root,text="Patient ID",width=20,height=2)
    w.place(x=400,y=150)
    t=Entry(root,borderwidth=5, width = 50)
    t.place(x=600,y=150)
    
    w1=Label(root,text="Name",width=20,height=2)
    w1.place(x=400,y=200)
    t1=Entry(root,borderwidth=5, width = 50)
    t1.place(x=600,y=200)
    
    w2=Label(root,text="Contact Number",width=20,height=2)
    w2.place(x=400,y=250)
    t2=Entry(root,borderwidth=5, width = 50)
    t2.place(x=600,y=250)

    
    w3=Label(root,text="Gender",width=20,height=2)
    w3.place(x=400,y=300)
    t3 = StringVar()
    t3.set('Female')
    r1 = Radiobutton(root, text='Male', variable=t3, value='Male')
    r1.place(x=600,y=300)

    r2 = Radiobutton(root, text='Female', variable=t3, value='Female')
    r2.place(x=700,y=300)

    
    w4=Label(root,text="Age",width=20,height=2)
    w4.place(x=400,y=350)
    t4=Entry(root,borderwidth=5, width = 50)
    t4.place(x=600,y=350)
    
    
    w5=Label(root,text="Date",width=20,height=2)
    w5.place(x=400,y=400)
    t5=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t5.place(x=600,y=400)
    
    w6=Label(root,text="select Test",width=20,height=2)
    w6.place(x=400,y=450)
    t6 = StringVar(root)
    t6.set("Select") 

    a= OptionMenu(root, t6, " Molecular (RT-PCR) tests", "COVID-19 Antigen Tests", "COVID-19 Antibody Tests ")
    a.config(width=20, font=('Helvetica', 12))
    a.place(x=600,y=450)


    w7=Label(root,text="Test Status",width=20,height=2)
    w7.place(x=400,y=500)
    t7 = StringVar()
    t7.set('Positive')
    r1 = Radiobutton(root, text='Positive', variable=t7, value='Positive')
    r1.place(x=600,y=500)

    r2 = Radiobutton(root, text='Negative', variable=t7, value='Negative')
    r2.place(x=700,y=500)
    
    
    w8=Label(root,text="Quarantine Status",width=20,height=2)
    w8.place(x=400,y=550)
    t8 = StringVar()
    t8.set('Home Quarantine')
    r1 = Radiobutton(root, text='Home Quarantine', variable=t8, value='Home Quarantine')
    r1.place(x=600,y=550)

    r2 = Radiobutton(root, text='Admitted In Hospital', variable=t8, value='Admitted In Hospital')
    r2.place(x=800,y=550)

    
    w9=Label(root,text="Next CheckUp",width=20,height=2)
    w9.place(x=400,y=600)
    t9=DateEntry(root, width= 50, background= "magenta3", foreground= "white",bd=2)
    t9.place(x=600,y=600)

    w10=Label(root,text="Address",width=20,height=2)
    w10.place(x=400,y=650)
    t10=Text(root,borderwidth=4, width = 40,height=4)
    t10.place(x=600,y=650)






    def att():
        con=my.connect(host="localhost",user="root",password="123456",database="covid")
        cursor=con.cursor()
        c="INSERT INTO covidtest(id,name,contact,gender,age,date,test,test_status,quarantine,checkup,address) values('"+t.get()+"','"+t1.get()+"','"+t2.get()+"','"+t3.get()+"','"+t4.get()+"','"+t5.get()+"','"+t6.get()+"','"+t7.get()+"','"+t8.get()+"','"+t9.get()+"','"+t10.get("1.0",END)+"')"
        cursor.execute(c)
        cursor.execute("commit")
        msg.showinfo("Submit Status","Added Successfully")
        t.delete(0, END)
        t1.delete(0, END)
        t2.delete(0, END)
        t4.delete(0, END)
        t5.delete(0, END)
        t9.delete(0, END) 
        t10.delete(1.0, END)
    b=Button(root,text="Submit",command=att,width=20, height=2)
    b.place(x=1000,y=200)
    
    def Clear():
        t.delete(0, END)
        t1.delete(0, END)
        t2.delete(0, END)
        t4.delete(0, END)
        t5.delete(0, END)
        t9.delete(0, END) 
        t10.delete(1.0, END)

    
    b1= Button(root, text="Clear",width=20, height=2,command=Clear)
    b1.place(x=1000,y=300)

    def back():
        test.cl()
        root.destroy()
    b2=Button(root,text="Back",command=back,width=20, height=2)
    b2.place(x=1000,y=400)




    
    
