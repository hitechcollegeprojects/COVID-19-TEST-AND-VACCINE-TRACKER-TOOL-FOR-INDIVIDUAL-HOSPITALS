from tkinter import*
import mysql.connector as my
from tkinter import messagebox as msg
def ulogin():
    root = Tk()
    root.geometry("1400x1400")
    root.title("User Login")
    
    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "2.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    C.place(x=0,y=0)

    
    m=Label(root,text="USER LOGIN",fg="Black",width=30,height=2,font=("Arial",25,"bold"))
    m.place(x=400,y=30)

    w=Label(root,text="User Name",width=15, height=2,fg="Black",bg="white",font=("Times",13,"bold"))
    w.place(x=500,y=300)
    z=Label(root,text="Password",width=15, height=2,fg="Black",bg="white",font=("Times",13,"bold"))
    z.place(x=500,y=400)
    t=Entry(root,borderwidth=2, width = 25,font=("Arial",13,"bold"))
    t.place(x=680,y=315)
    t1=Entry(root,borderwidth=2, width = 25, show="*",font=("Arial",13,"bold"))
    t1.place(x=680,y=415)
    
    def llen():
        con=my.connect(host="localhost",user="root",password="123456",database="covid")
        cur=con.cursor()
        cur.execute("select * from userlogin where username='"+t.get()+"' and password='"+t1.get()+"'")
        d=cur.fetchall()
        if d:
            msg.showinfo("Login Status","Login Successfully "+t.get())
            t.delete(0, END)
            t1.delete(0, END)
            for x in d:
                ureport.dk()
                root.destroy()
        else:
            msg.showinfo("Login Status","Username/Password Invalid "+t.get())
        

    b=Button(root,text="Login",command=llen,width=10,height=1,fg="Black",bg="white",font=("Times",12,"bold"))
    b.place(x=640,y=500)
    root.mainloop()


    
