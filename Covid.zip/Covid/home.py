from tkinter import*
import admin_login
import user_login

def homepage():
    root = Tk()
    root.title("CENTRALIZED VACCINE REPORT")
    root.geometry("1400x1400")

    C = Canvas(root, bg="blue", height=250, width=300)
    filename = PhotoImage(file = "home.png")
    background_label = Label(root, image=filename)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    C.place(x=0,y=0)
    
    m=Label(root,text="COVID-19 TEST AND VACCINE TRACKER",fg="Black",bg="white",width=35,height=2,font=("Arial",25,"bold"))
    m.place(x=550,y=30)

    def adminlogin():
        admin_login.alogin()

        root.destroy()
    b=Button(root,text="Admin Login",command=adminlogin,width=12, height=2,fg="Black",bg="white",font=("Verdana",11,"bold"))
    b.place(x=700,y=300)

    def userlogin():
        user_login.ulogin()
        root.destroy()
    b1=Button(root,text="User Login",command=userlogin,width=12, height=2,fg="Black",bg="white",font=("Verdana",11,"bold"))
    b1.place(x=900,y=300)

    def close():
        root.destroy()
    b2=Button(root,text="Exit",command=close,width=10, height=1,fg="Black",bg="white",font=("Arial Black",15,"bold"))
    b2.place(x=800,y=400)
    root.mainloop()
def call():
    homepage()
call()
